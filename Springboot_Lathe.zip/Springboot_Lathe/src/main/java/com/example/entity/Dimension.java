package com.example.entity;

public class Dimension {

}
